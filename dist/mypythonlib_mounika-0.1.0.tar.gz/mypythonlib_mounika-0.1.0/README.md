# mypythonlib

This is my first Python library. It includes a function to calculate the great circle distance between two points on Earth.
